package com.example.crate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.crate.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding= ActivityMainBinding.inflate(layoutInflater)
        val view=binding.root
        setContentView(view)

        binding.button.setOnClickListener {
            val value1=binding.length.text.toString().toFloat()
            val value2=binding.width.text.toString().toFloat()
            val value3=binding.height.text.toString().toFloat()

            val calV= value1*value2*value3
            val calC= calV*.23
            val calCC= calV*.5
            val calP= calCC-calC

            binding.disv.text=calV.toString()
            binding.disc.text=calC.toString()
            binding.discc.text=calCC.toString()
            binding.disp.text=calP.toString()
        }




    }
}